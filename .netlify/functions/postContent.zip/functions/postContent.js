var import_defines = require("./util/defines");
var import_insta_helper = require("./util/insta_helper");
const { requestObj, responseObj } = require("./util/helper");
exports.handler = async (event, context) => {
  let data = requestObj(event.body);
  console.log(data);
  try {
    let params = (0, import_defines.getCreds)();
    params["media_type"] = "IMAGE";
    params["media_url"] = "https://justinstolpe.com/sandbox/ig_publish_content_img.png";
    params["caption"] += "\nThis content is managed by Instbit\n";
    params["caption"] += "\n#instagram #graphapi #instagramgraphapi #code #coding #programming #python #api #webdeveloper #codinglife #developer #coder #tech #developerlife #webdev #instgramgraphapi";
    let imageMediaObjectResponse = (0, import_insta_helper.createMediaObject)(params);
    let imageMediaObjectId = imageMediaObjectResponse["json_data"]["id"];
    let imageMediaStatusCode = "IN_PROGRESS";
    while (imageMediaStatusCode !== "FINISHED") {
      let imageMediaObjectStatusResponse = (0, import_insta_helper.getMediaObjectStatus)(imageMediaObjectId, params);
      imageMediaStatusCode = imageMediaObjectStatusResponse["json_data"]["status_code"];
      console.log("\n---- IMAGE MEDIA OBJECT STATUS -----\n");
      console.log("	Status Code:");
      console.log("	" + imageMediaStatusCode);
      (0, import_insta_helper.sleep)(5);
    }
    let publishImageResponse = (0, import_insta_helper.publishMedia)(imageMediaObjectId, params);
    console.log("\n---- PUBLISHED IMAGE RESPONSE -----\n");
    console.log("	Response:");
    console.log(publishImageResponse["resp"]);
    let contentPublishingApiLimit = (0, import_insta_helper.getContentPublishingLimit)(params);
    console.log("\n---- CONTENT PUBLISHING USER API LIMIT -----\n");
    console.log("	Response:");
    console.log(contentPublishingApiLimit["resp"]);
  } catch (error) {
    console.log(error);
    return responseObj(500, error);
  }
};
