var __create = Object.create;
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __getProtoOf = Object.getPrototypeOf;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toESM = (mod, isNodeMode, target) => (target = mod != null ? __create(__getProtoOf(mod)) : {}, __copyProps(isNodeMode || !mod || !mod.__esModule ? __defProp(target, "default", { value: mod, enumerable: true }) : target, mod));
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);
var defines_exports = {};
__export(defines_exports, {
  getCreds: () => getCreds,
  makeApiCall: () => makeApiCall
});
module.exports = __toCommonJS(defines_exports);
var import_axios = __toESM(require("axios"));
function getCreds() {
  const access_token = "ACCESS-TOKEN";
  const graph_domain = "https://graph.facebook.com/";
  const graph_version = "v6.0";
  const instagram_account_id = "INSTAGRAM-BUSINESS-ACCOUNT-ID";
  return {
    access_token,
    graph_domain,
    graph_version,
    endpoint_base: graph_domain + graph_version + "/",
    instagram_account_id
  };
}
function makeApiCall(url, payload, type) {
  let data;
  if (type === "POST") {
    data = import_axios.default.post(url, payload);
  } else {
    const endpointParams = new url.URLSearchParams(payload);
    data = import_axios.default.get(url, endpointParams);
  }
  return {
    url,
    req: payload,
    resp: data.content
  };
}
// Annotate the CommonJS export names for ESM import in node:
0 && (module.exports = {
  getCreds,
  makeApiCall
});
